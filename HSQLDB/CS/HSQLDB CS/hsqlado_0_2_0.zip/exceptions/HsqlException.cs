using System;

namespace sf.net.hsqlado.exceptions
{
	public class HsqlException : Exception
	{
		public HsqlException(string message) : base(message)
		{
		}
	}
}