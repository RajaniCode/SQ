Rem^M
Rem $Header: InstantClient.sql 30-Oct-2006.17:43:34 yxliu Exp $^M
Rem^M
Rem InstantClient.sql^M
Rem^M
Rem Copyright (c) 2003, 2004, Oracle. All rights reserved.
Rem^M
Rem    NAME^M
Rem      InstantClient.sql - <one-line expansion of the name>^M
Rem^M
Rem    DESCRIPTION^M
Rem      <short description of component this file declares/defines>^M
Rem^M
Rem    NOTES^M
Rem      <other useful comments, qualifications, etc.>^M
Rem^M
Rem    MODIFIED   (MM/DD/YY)^M
Rem    yixliu      10/30/06 - Created^M
Rem^M

SET ECHO ON

show _vfstype;
exit
