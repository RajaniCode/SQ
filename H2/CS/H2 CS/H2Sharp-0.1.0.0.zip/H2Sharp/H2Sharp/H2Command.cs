#region MIT License
/*
 * Copyright � 2008 Jonathan Mark Porter.
 * H2Sharp is a wrapper for the H2 Database Engine. http://h2sharp.googlecode.com
 * 
 * Permission is hereby granted, free of charge, to any person
 * obtaining a copy of this software and associated documentation
 * files (the "Software"), to deal in the Software without
 * restriction, including without limitation the rights to use,
 * copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following
 * conditions:
 * 
 * The above copyright notice and this permission notice shall be
 * included in all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
 * OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
 * HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
 * WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 */
#endregion

using System.Collections.Generic;
using System.Text;
using java.sql;

using DbCommand = System.Data.Common.DbCommand;
using DbConnection = System.Data.Common.DbConnection;
using DbDataReader = System.Data.Common.DbDataReader;
using DbParameter = System.Data.Common.DbParameter;
using DbParameterCollection = System.Data.Common.DbParameterCollection;
using DbTransaction = System.Data.Common.DbTransaction;

namespace System.Data.H2
{
    public sealed class H2Command : DbCommand
    {
        class PreparedTemplate
        {
            private string trueSql;
            private int[] mapping;
            public PreparedTemplate(string trueSql, int[] mapping)
            {
                this.trueSql = trueSql;
                this.mapping = mapping;
            }
            public string TrueSql
            {
                get { return trueSql; }
            }
            public int[] Mapping
            {
                get { return mapping; }
            }
        }
        static Dictionary<string, PreparedTemplate> templates = new Dictionary<string, PreparedTemplate>();
        static object syncRoot = new object();

        H2Connection connection;
        CommandType commandType;
        string commandText;
        int commandTimeout=30;
        bool timeoutSet = false;
        bool designTimeVisible;
        H2ParameterCollection collection;
        PreparedStatement statement;


        public H2Command()
        {
            this.collection = new H2ParameterCollection();
        }
        public H2Command(H2Connection parent):this()
        {
            this.connection = parent;
        }

        protected override DbConnection DbConnection
        {
            get
            {
                return connection;
            }
            set
            {
                connection = (H2Connection)value;
            }
        }
        protected override DbParameterCollection DbParameterCollection
        {
            get { return collection; }
        }
        protected override DbTransaction DbTransaction
        {
            get
            {
                return connection.transaction;
            }
            set
            {
                this.DbConnection = value.Connection;
            }
        }

        public override string CommandText
        {
            get
            {
                return commandText;
            }
            set
            {
                commandText = value;
            }
        }
        public override int CommandTimeout
        {
            get
            {
                return commandTimeout;
            }
            set
            {
                timeoutSet = true;
                commandTimeout = value;
            }
        }
        public override CommandType CommandType
        {
            get { return commandType; }
            set { commandType = value; }
        }
        public override bool DesignTimeVisible
        {
            get
            {
                return designTimeVisible;
            }
            set
            {
                designTimeVisible = value;
            }
        }
        public override UpdateRowSource UpdatedRowSource
        {
            get
            {
                throw new NotImplementedException();
            }
            set
            {
                throw new NotImplementedException();
            }
        }

        private void CheckConnection()
        {
            if (connection == null) { throw new H2Exception("DbConnection must be set."); }
        }
        private PreparedTemplate CreateTemplate()
        {
            List<int> list = new List<int>();
            StringBuilder command = new StringBuilder();
            StringBuilder name = new StringBuilder();
            foreach (char c in commandText)
            {
                if (name.Length == 0)
                {
                    if (c == '@')
                    {
                        name.Append(c);
                    }
                    else
                    {
                        command.Append(c);
                    }
                }
                else
                {
                    if (char.IsLetterOrDigit(c) || c == '_')
                    {
                        name.Append(c);
                    }
                    else
                    {
                        command.Append('?');
                        command.Append(c);
                        string temp = name.ToString();
                        name.Length = 0;
                        int index = collection.parameters.FindIndex(delegate(H2Parameter p) { return p.ParameterName == temp; });
                        if (index == -1) { throw new H2Exception("missing parameter"); }
                        list.Add(index);
                    }
                }
            }
            return new PreparedTemplate(command.ToString(), list.ToArray());
        }
        private PreparedStatement CreateStatment()
        {
            if (commandText.Contains("@"))
            {
                PreparedTemplate template;
                lock (syncRoot)
                {
                    if (!templates.TryGetValue(commandText, out template))
                    {
                        template = CreateTemplate();
                        templates.Add(commandText, template);
                    }
                }
                PreparedStatement statement = connection.connection.prepareStatement(template.TrueSql);
                if (timeoutSet) { statement.setQueryTimeout(commandTimeout); }
                for (int index = 0; index < template.Mapping.Length; ++index)
                {
                    statement.setObject(index + 1, collection.GetJavaValue(template.Mapping[index]));
                }
                return statement;
            }
            else if (commandText.Contains("?"))
            {
                PreparedStatement statement = connection.connection.prepareStatement(commandText);
                if (timeoutSet) { statement.setQueryTimeout(commandTimeout); }
                for (int index = 0; index < collection.Count; ++index)
                {
                    statement.setObject(index + 1, collection.GetJavaValue(index));
                }
                return statement;
            }
            else
            {
                PreparedStatement statement = connection.connection.prepareStatement(commandText);
                if (timeoutSet) { statement.setQueryTimeout(commandTimeout); }
                return statement;
            }
        }

        protected override DbParameter CreateDbParameter()
        {
            return new H2Parameter();
        }
        protected override DbDataReader ExecuteDbDataReader(CommandBehavior behavior)
        {
            CheckConnection();
            statement = CreateStatment();
            H2DataReader result = new H2DataReader(statement.executeQuery());
            statement = null;
            return result;
        }

        public override void Cancel()
        {
            CheckConnection();
            if (statement != null)
            {
                statement.cancel();
            }
        }
        public override int ExecuteNonQuery()
        {
            CheckConnection();
            statement = CreateStatment();
            int result = statement.executeUpdate();
            statement = null;
            return result;
        }
        public override object ExecuteScalar()
        {
            CheckConnection();
            statement = CreateStatment();
            ResultSet set = statement.executeQuery();
            statement = null;
            object result = null;
            try
            {
                if (set.next())
                {
                    result = set.getObject(1);
                    result = H2Helper.ConvertToDotNet(result);
                }
            }
            finally
            {
                set.close();
            }
            return result;
        }
        public override void Prepare()
        {
            CheckConnection();
            CreateStatment();
        }
    }

}