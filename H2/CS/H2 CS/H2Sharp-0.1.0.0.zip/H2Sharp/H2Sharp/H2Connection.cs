#region MIT License
/*
 * Copyright � 2008 Jonathan Mark Porter.
 * H2Sharp is a wrapper for the H2 Database Engine. http://h2sharp.googlecode.com
 * 
 * Permission is hereby granted, free of charge, to any person
 * obtaining a copy of this software and associated documentation
 * files (the "Software"), to deal in the Software without
 * restriction, including without limitation the rights to use,
 * copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following
 * conditions:
 * 
 * The above copyright notice and this permission notice shall be
 * included in all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
 * OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
 * HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
 * WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 */
#endregion

using java.sql;
using org.h2.jdbcx;
using DbCommand = System.Data.Common.DbCommand;
using DbConnection = System.Data.Common.DbConnection;
using DbTransaction = System.Data.Common.DbTransaction;

namespace System.Data.H2
{
    public sealed class H2Connection : DbConnection
    {
        string url;
        internal H2Transaction transaction;
        internal Connection connection;
        string userName;
        string password;
        JdbcConnectionPool man;
        public H2Connection(string url)
        {
            this.url = url;
        }
        public H2Connection(string url, string userName, string password)
        {
            this.url = url;
            this.userName = userName;
            this.password = password;
        }
        internal H2Connection(Connection self)
        {
            this.connection = self;
            if (H2Helper.GetAdoTransactionLevel(self.getTransactionIsolation()) != IsolationLevel.Unspecified)
            {
                this.transaction = new H2Transaction(this);
            }
        }
        internal H2Connection(JdbcConnectionPool man)
        {
            this.man = man;
        }


        public bool IsOpen { get { return connection != null; } }

        protected override DbTransaction BeginDbTransaction(IsolationLevel isolationLevel)
        {
            if (isolationLevel == IsolationLevel.Unspecified)
            {
                isolationLevel = IsolationLevel.ReadCommitted;
            }
            if (transaction != null) { throw new InvalidOperationException(); }
            connection.setTransactionIsolation(H2Helper.GetJdbcTransactionLevel(isolationLevel));
            transaction = new H2Transaction(this);
            return transaction;
        }

        public override void ChangeDatabase(string databaseName)
        {
            throw new NotImplementedException();
        }
        protected override void Dispose(bool disposing)
        {
            base.Dispose(disposing);
            if (disposing)
            {
                if (transaction != null)
                {
                    transaction.Dispose();
                    transaction = null;
                }
                Close();
            }
        }
        public override void Close()
        {
            if (IsOpen)
            {
                connection.close();
                connection = null;
            }
        }

        public override string ConnectionString
        {
            get { return url; }
            set
            {
                if (IsOpen) { throw new InvalidOperationException(); }
                url = value;
            }
        }
        public string UserName
        {
            get { return userName; }
            set
            {
                if (IsOpen) { throw new InvalidOperationException(); }
                userName = value;
            }
        }
        public string Password
        {
            get { return password; }
            set
            {
                if (IsOpen) { throw new InvalidOperationException(); }
                password = value;
            }
        }


        protected override DbCommand CreateDbCommand()
        {
            return new H2Command(this);
        }

        public override string DataSource
        {
            get { throw new NotImplementedException(); }
        }

        public override string Database
        {
            get { throw new NotImplementedException(); }
        }

        public override void Open()
        {
            if (IsOpen) { throw new H2Exception("connection is already open"); }
            if (man != null)
            {
                if (userName == null || password == null)
                {
                    this.connection = man.getConnection();
                }
                else 
                {
                    this.connection = man.getConnection(userName, password);
                }
            }
            else if (userName == null || password == null)
            {
                this.connection = java.sql.DriverManager.getConnection(url);
            }
            else
            {
                this.connection = java.sql.DriverManager.getConnection(url, userName, password);
            }
        }

        public override string ServerVersion
        {
            get { throw new NotImplementedException(); }
        }

        public override ConnectionState State
        {
            get
            {
                if (connection == null) { return ConnectionState.Closed; }
                return ConnectionState.Open;
            }
        }
    }

}