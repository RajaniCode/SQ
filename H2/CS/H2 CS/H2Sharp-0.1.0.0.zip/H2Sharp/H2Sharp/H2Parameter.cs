#region MIT License
/*
 * Copyright � 2008 Jonathan Mark Porter.
 * H2Sharp is a wrapper for the H2 Database Engine. http://h2sharp.googlecode.com
 * 
 * Permission is hereby granted, free of charge, to any person
 * obtaining a copy of this software and associated documentation
 * files (the "Software"), to deal in the Software without
 * restriction, including without limitation the rights to use,
 * copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following
 * conditions:
 * 
 * The above copyright notice and this permission notice shall be
 * included in all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
 * OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
 * HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
 * WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 */
#endregion

using DbParameter = System.Data.Common.DbParameter;

namespace System.Data.H2
{
    public sealed class H2Parameter : DbParameter
    {
        DbType dbType;
        ParameterDirection direction;
        bool isNullable;
        string parameterName;
        int size;
        object value;
        object javaValue;


        public H2Parameter() { }
        public H2Parameter(string parameterName)
        {
            this.parameterName = parameterName;
        }
        public H2Parameter(string parameterName, object value)
        {
            this.parameterName = parameterName;
            this.Value = value;
        }
        public H2Parameter(object value)
        {
            this.Value = value;
        }

        public override DbType DbType
        {
            get { return dbType; }
            set { dbType = value; }
        }

        public override ParameterDirection Direction
        {
            get { return direction; }
            set { direction = value; }
        }

        public override bool IsNullable
        {
            get { return isNullable; }
            set { isNullable = value; }
        }

        public override string ParameterName
        {
            get { return parameterName; }
            set { this.parameterName = value; }
        }

        public override void ResetDbType()
        {
            dbType = DbType.Object;
        }

        public override int Size
        {
            get { return size; }
            set { size = value; }
        }

        public override string SourceColumn
        {
            get
            {
                throw new NotImplementedException();
            }
            set
            {
                throw new NotImplementedException();
            }
        }

        public override bool SourceColumnNullMapping
        {
            get
            {
                throw new NotImplementedException();
            }
            set
            {
                throw new NotImplementedException();
            }
        }

        public override DataRowVersion SourceVersion
        {
            get
            {
                throw new NotImplementedException();
            }
            set
            {
                throw new NotImplementedException();
            }
        }

        public override object Value
        {
            get { return value; }
            set 
            {
                this.value = value;
                this.javaValue = H2Helper.ConvertToJava(value);
            }
        }
        internal object JavaValue
        {
            get { return javaValue; }
        }
    }

}